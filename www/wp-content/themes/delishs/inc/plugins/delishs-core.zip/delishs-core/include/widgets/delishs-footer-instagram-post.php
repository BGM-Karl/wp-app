<?php

/**

 * Delishs Footer Image Gallery
 * @author     RRdevs
 * @category   Widgets
 * @package    Delishs/Widgets
 * @version    1.0.0
 * @extends    WP_Widget
 */

add_action( 'widgets_init', function () {
    register_widget( 'Delishs_footer_instagram_post' );
} );

class Delishs_footer_instagram_post extends WP_Widget {

    public function __construct() {

        parent::__construct( 'Delishs_footer_instagram_post', esc_html__( 'Delishs Footer Instagram Post', 'delishs-core' ), array(
            'description' => esc_html__( 'Show Footer Instagram Post Widget By Delishs', 'delishs-core' ),

        ) );

    }

    public function widget( $args, $instance ) {

        extract( $args );

        extract( $instance );

        print $before_widget;

        if ( !empty( $title ) ) {

            print $before_title . apply_filters( 'widget_title', $title ) . $after_title;

        }

        ?>

            <div class="rr-instragram-gallery">
                <?php if ( !empty( $gallery_img_1 ) ): ?>
                    <a target="_blank" href="<?php print esc_url( $gallery_img_url_1 );?>">
                        <img src="<?php print $gallery_img_1;?>" alt="<?php print esc_html__( 'Instagram Post', 'delishs-core' );?>">
                    </a>
                <?php endif;?>

                <?php if ( !empty( $gallery_img_2 ) ): ?>
                    <a target="_blank" href="<?php print esc_url( $gallery_img_url_2 );?>">
                        <img src="<?php print $gallery_img_2;?>" alt="<?php print esc_html__( 'Instagram Post', 'delishs-core' );?>">
                    </a>
                <?php endif;?>

                <?php if ( !empty( $gallery_img_3 ) ): ?>
                    <a target="_blank" href="<?php print esc_url( $gallery_img_url_3 );?>">
                        <img src="<?php print $gallery_img_3;?>" alt="<?php print esc_html__( 'Instagram Post', 'delishs-core' );?>">
                    </a>
                <?php endif;?>

                <?php if ( !empty( $gallery_img_4 ) ): ?>
                    <a target="_blank" href="<?php print esc_url( $gallery_img_url_4 );?>">
                        <img src="<?php print $gallery_img_4;?>" alt="<?php print esc_html__( 'Instagram Post', 'delishs-core' );?>">
                    </a>
                <?php endif;?>

                <?php if ( !empty( $gallery_img_5 ) ): ?>
                    <a target="_blank" href="<?php print esc_url( $gallery_img_url_5 );?>">
                        <img src="<?php print $gallery_img_5;?>" alt="<?php print esc_html__( 'Instagram Post', 'delishs-core' );?>">
                    </a>
                <?php endif;?>

                <?php if ( !empty( $gallery_img_6 ) ): ?>
                    <a target="_blank" href="<?php print esc_url( $gallery_img_url_6 );?>">
                        <img src="<?php print $gallery_img_6;?>" alt="<?php print esc_html__( 'Instagram Post', 'delishs-core' );?>">
                    </a>
                <?php endif;?>
            </div>

			<?php print $after_widget;?>

		<?php

    }

    /**
     * widget function.
     *
     * @see WP_Widget
     * @access public
     * @param array $instance
     * @return void
     */

    public function form( $instance ) {

        $title = isset( $instance['title'] ) ? $instance['title'] : '';

        $gallery_img_1 = isset( $instance['gallery_img_1'] ) ? $instance['gallery_img_1'] : '';
        $gallery_img_2 = isset( $instance['gallery_img_2'] ) ? $instance['gallery_img_2'] : '';
        $gallery_img_3 = isset( $instance['gallery_img_3'] ) ? $instance['gallery_img_3'] : '';
        $gallery_img_4 = isset( $instance['gallery_img_4'] ) ? $instance['gallery_img_4'] : '';
        $gallery_img_5 = isset( $instance['gallery_img_5'] ) ? $instance['gallery_img_5'] : '';
        $gallery_img_6 = isset( $instance['gallery_img_6'] ) ? $instance['gallery_img_6'] : '';

        $gallery_img_url_1 = isset( $instance['gallery_img_url_1'] ) ? $instance['gallery_img_url_1'] : '';
        $gallery_img_url_2 = isset( $instance['gallery_img_url_2'] ) ? $instance['gallery_img_url_2'] : '';
        $gallery_img_url_3 = isset( $instance['gallery_img_url_3'] ) ? $instance['gallery_img_url_3'] : '';
        $gallery_img_url_4 = isset( $instance['gallery_img_url_4'] ) ? $instance['gallery_img_url_4'] : '';
        $gallery_img_url_5 = isset( $instance['gallery_img_url_5'] ) ? $instance['gallery_img_url_5'] : '';
        $gallery_img_url_6 = isset( $instance['gallery_img_url_6'] ) ? $instance['gallery_img_url_6'] : '';

        ?>

		<p>
			<label for="title"><?php esc_html_e( 'Title:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'title' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'title' ) );?>" value="<?php print esc_attr( $title );?>">
		</p>

		<p>
			<button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
			<input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_1' ) );?>" class="image_er_link" value="<?php print $gallery_img_1;?>">
			<div class="author-image-show">
				<img src="<?php print $gallery_img_1;?>" alt="" width="150" height="auto">
			</div>
		</p>

		<p>
			<label for="title"><?php esc_html_e( 'URL:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'gallery_img_url_1' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'gallery_img_url_1' ) );?>" value="<?php print esc_attr( $gallery_img_url_1 );?>">
		</p>

		<p>
			<button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
			<input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_2' ) );?>" class="image_er_link" value="<?php print $gallery_img_2;?>">
			<div class="author-image-show">
				<img src="<?php print $gallery_img_2;?>" alt="" width="150" height="auto">
			</div>
		</p>

		<p>
			<label for="title"><?php esc_html_e( 'URL:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'gallery_img_url_2' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'gallery_img_url_2' ) );?>" value="<?php print esc_attr( $gallery_img_url_2 );?>">
		</p>

		<p>
			<button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
			<input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_3' ) );?>" class="image_er_link" value="<?php print $gallery_img_3;?>">
			<div class="author-image-show">
				<img src="<?php print $gallery_img_3;?>" alt="" width="150" height="auto">
			</div>
		</p>

		<p>
			<label for="title"><?php esc_html_e( 'URL:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'gallery_img_url_3' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'gallery_img_url_3' ) );?>" value="<?php print esc_attr( $gallery_img_url_3 );?>">
		</p>

		<p>
			<button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
			<input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_4' ) );?>" class="image_er_link" value="<?php print $gallery_img_4;?>">
			<div class="author-image-show">
				<img src="<?php print $gallery_img_4;?>" alt="" width="150" height="auto">
			</div>
		</p>

		<p>
			<label for="title"><?php esc_html_e( 'URL:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'gallery_img_url_4' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'gallery_img_url_4' ) );?>" value="<?php print esc_attr( $gallery_img_url_4 );?>">
		</p>

		<p>
			<button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
			<input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_5' ) );?>" class="image_er_link" value="<?php print $gallery_img_5;?>">
			<div class="author-image-show">
				<img src="<?php print $gallery_img_5;?>" alt="" width="150" height="auto">
			</div>
		</p>

		<p>
			<label for="title"><?php esc_html_e( 'URL:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'gallery_img_url_5' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'gallery_img_url_5' ) );?>" value="<?php print esc_attr( $gallery_img_url_5 );?>">
		</p>

		<p>
			<button type="submit" class="button button-secondary" id="author_info_image">Upload Media</button>
			<input type="hidden" name="<?php print esc_attr( $this->get_field_name( 'gallery_img_6' ) );?>" class="image_er_link" value="<?php print $gallery_img_6;?>">
			<div class="author-image-show">
				<img src="<?php print $gallery_img_6;?>" alt="" width="150" height="auto">
			</div>
		</p>

		<p>
			<label for="title"><?php esc_html_e( 'URL:', 'delishs-core' );?></label>
			<input type="text" class="widefat" id="<?php print esc_attr( $this->get_field_id( 'gallery_img_url_6' ) );?>"  name="<?php print esc_attr( $this->get_field_name( 'gallery_img_url_6' ) );?>" value="<?php print esc_attr( $gallery_img_url_6 );?>">
		</p>

		<?php

    }

    public function update( $new_instance, $old_instance ) {

        $instance = array();

        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        $instance['gallery_img_url_1'] = ( !empty( $new_instance['gallery_img_url_1'] ) ) ? strip_tags( $new_instance['gallery_img_url_1'] ) : '';
        $instance['gallery_img_url_2'] = ( !empty( $new_instance['gallery_img_url_2'] ) ) ? strip_tags( $new_instance['gallery_img_url_2'] ) : '';
        $instance['gallery_img_url_3'] = ( !empty( $new_instance['gallery_img_url_3'] ) ) ? strip_tags( $new_instance['gallery_img_url_3'] ) : '';
        $instance['gallery_img_url_4'] = ( !empty( $new_instance['gallery_img_url_4'] ) ) ? strip_tags( $new_instance['gallery_img_url_4'] ) : '';
        $instance['gallery_img_url_5'] = ( !empty( $new_instance['gallery_img_url_5'] ) ) ? strip_tags( $new_instance['gallery_img_url_5'] ) : '';
        $instance['gallery_img_url_6'] = ( !empty( $new_instance['gallery_img_url_6'] ) ) ? strip_tags( $new_instance['gallery_img_url_6'] ) : '';

        $instance['gallery_img_1'] = ( !empty( $new_instance['gallery_img_1'] ) ) ? strip_tags( $new_instance['gallery_img_1'] ) : '';
        $instance['gallery_img_2'] = ( !empty( $new_instance['gallery_img_2'] ) ) ? strip_tags( $new_instance['gallery_img_2'] ) : '';
        $instance['gallery_img_3'] = ( !empty( $new_instance['gallery_img_3'] ) ) ? strip_tags( $new_instance['gallery_img_3'] ) : '';
        $instance['gallery_img_4'] = ( !empty( $new_instance['gallery_img_4'] ) ) ? strip_tags( $new_instance['gallery_img_4'] ) : '';
        $instance['gallery_img_5'] = ( !empty( $new_instance['gallery_img_5'] ) ) ? strip_tags( $new_instance['gallery_img_5'] ) : '';
        $instance['gallery_img_6'] = ( !empty( $new_instance['gallery_img_6'] ) ) ? strip_tags( $new_instance['gallery_img_6'] ) : '';

        return $instance;

    }

}